#!/bin/bash

# 启动Ollama服务
echo "Starting Ollama server..."
ollama serve &
OLLAMA_PID=$!

# 等待服务启动
echo "Waiting for Ollama service to start..."
sleep 5

# 检查服务是否启动成功
for i in {1..30}; do
    if curl -s http://localhost:11434/api/tags > /dev/null 2>&1; then
        echo "Ollama service is ready!"
        break
    fi
    echo "Waiting for Ollama service... ($i/30)"
    sleep 2
done

# 拉取模型
echo "Pulling qwen3:0.6b model..."
ollama pull qwen3:0.6b

echo "Model loaded successfully!"
echo "Ollama API is available at http://0.0.0.0:11434"

# 保持容器运行
wait $OLLAMA_PID