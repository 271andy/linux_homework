import os
import httpx
from mcp.types import TextContent

AUTH_TOKEN = os.getenv("MCP_AUTH_TOKEN", "abc123")

async def search_bilibili_first_video(keyword: str, token: str) -> list[TextContent]:
    """根据关键词搜索B站，返回第一个视频名称，需要token鉴权"""
    if token != AUTH_TOKEN:
        return [TextContent(type="text", text="鉴权失败：token 无效")]

    url = "https://api.bilibili.com/x/web-interface/search/type"
    params = {"search_type": "video", "keyword": keyword, "page": 1}
    headers = {"User-Agent": "Mozilla/5.0 (compatible; MCP-Bot/1.0)"}

    try:
        async with httpx.AsyncClient() as client:
            resp = await client.get(url, params=params, headers=headers, timeout=10)
            data = resp.json()
            result = data.get("data", {}).get("result")
            if not result:
                return [TextContent(type="text", text="未找到相关视频")]
            title = result[0]["title"].replace('<em class="keyword">', '').replace('</em>', '')
            return [TextContent(type="text", text=title)]
    except Exception as e:
        return [TextContent(type="text", text=f"搜索失败：{str(e)}")]