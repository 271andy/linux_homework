import os
from mcp.types import TextContent

AUTH_TOKEN = os.getenv("MCP_AUTH_TOKEN", "abc123")

async def get_token() -> list[TextContent]:
    """返回鉴权所需的 token，调用此工具不需要鉴权"""
    return [TextContent(type="text", text=AUTH_TOKEN)]