from mcp.server import Server
from mcp.server.sse import SseServerTransport
from tools import get_token, search_bilibili_first_video

server = Server("bilibili-search")

# 注册两个工具
server.tool()(get_token)
server.tool()(search_bilibili_first_video)

# SSE 传输
sse = SseServerTransport("/messages/")

async def handle_sse(scope, receive, send):
    async with sse.connect_sse(scope, receive, send) as (read, write):
        await server.run(read, write, server.create_initialization_options())

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("server:handle_sse", host="0.0.0.0", port=8000)