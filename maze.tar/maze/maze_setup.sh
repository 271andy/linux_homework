#!/bin/bash
# Maze Treasure Hunt - learn find command via puzzles
# All in English, zero dependencies.

set -e

MAZE_DIR="${1:-/tmp/maze}"

echo "Setting up the treasure maze in: $MAZE_DIR"
rm -rf "$MAZE_DIR"
mkdir -p "$MAZE_DIR"
cd "$MAZE_DIR"

# --- Generate decoy files & directories ---
echo "Generating decoy files..."
for i in $(seq 1 200); do
    dd if=/dev/urandom of="trash_$i.bin" bs=1 count=$((RANDOM % 1000 + 1)) status=none
done
for d in $(seq 1 30); do
    sub="sub_$RANDOM"
    mkdir -p "folder_$d/$sub"
    for f in $(seq 1 5); do
        touch "folder_$d/$sub/file_$RANDOM.log"
    done
done

# --- Place clues and treasure ---
echo "Placing clues..."

# Clue 1: exact name
mkdir -p folder_17/sub_91
cat > folder_17/sub_91/CLUE_1_START << 'EOF'
Clue 2 is the only file with a size of exactly 314 bytes.
Use find with -size to locate it.
EOF

# Clue 2: size = 314 bytes (content padded with nulls to exact size)
mkdir -p folder_5
echo -n "Well done! Clue 3 is a file modified within the last 7 days and ending with .cfg. Use find -mtime." > folder_5/node_B.info
truncate -s 314 folder_5/node_B.info

# Clue 3: .cfg file modified 3 days ago
mkdir -p folder_22
cat > folder_22/secret_42.cfg << 'EOF'
Level 4: Find the file with exact permissions 640 (rw-r-----). Its name is access_key.dat.
EOF
touch -d "3 days ago" folder_22/secret_42.cfg

# Clue 4: permissions 640
mkdir -p folder_3
cat > folder_3/access_key.dat << 'EOF'
Final level: Only one file contains the secret phrase 'OpenSesame'. Find it using: find -type f -exec grep ...
EOF
chmod 640 folder_3/access_key.dat

# Clue 5: contains the magic phrase
mkdir -p folder_13
cat > folder_13/riddle_final.txt << 'EOF'
The treasure is a file named Treasure_Box in this directory. Congratulations!
OpenSesame
EOF

# Treasure
cat > Treasure_Box << 'EOF'
 _________________________________
< You cracked the maze!           >
< Welcome to the find Master Hall >
 ---------------------------------
        \   ^__^
         \  (oo)\_______
            (__)\       )\/\
                ||----w |
                ||     ||
EOF

echo ""
echo "Maze setup complete!"
echo "--------------------"
echo "Start by finding CLUE_1_START inside $MAZE_DIR"
echo "Each clue tells you which find option to use next."
echo "Rules: only one find command per level, no ls -R!"
echo ""
echo "Good luck, explorer."